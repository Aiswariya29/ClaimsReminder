package com.mc.claimnote.service;

import com.mc.claimnote.exception.CategoryDoesNoteExistsException;
import com.mc.claimnote.exception.CategoryNotCreatedException;
import com.mc.claimnote.exception.CategoryNotFoundException;
import com.mc.claimnote.model.Category;
import java.util.List;

public interface CategoryService {
	
	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    Category createCategory(Category category) throws CategoryNotCreatedException;

    boolean deleteCategory(String categoryId) throws CategoryDoesNoteExistsException;

    Category updateCategory(Category category, String categoryId);

    Category getCategoryById(String categoryId) throws CategoryNotFoundException;

    List<Category> getAllCategoryByUserId(String userId);

}
