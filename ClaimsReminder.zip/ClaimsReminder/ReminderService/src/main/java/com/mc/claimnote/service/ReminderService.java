package com.mc.claimnote.service;

import com.mc.claimnote.exception.ReminderNotCreatedException;
import com.mc.claimnote.exception.ReminderNotFoundException;
import com.mc.claimnote.model.Reminder;

import java.util.List;

public interface ReminderService {
	
	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    Reminder createReminder(Reminder reminder) throws ReminderNotCreatedException;

    boolean deleteReminder(String reminderId) throws ReminderNotFoundException;

    Reminder updateReminder(Reminder reminder, String reminderId) throws ReminderNotFoundException;

    Reminder getReminderById(String reminderId) throws ReminderNotFoundException;

    List<Reminder> getAllReminders();
    
    List<Reminder> getAllRemindersByUserId(String userId);
}
