package com.mc.claimnote.exception;

public class UserNullException extends Exception {

    public UserNullException(String message) {
        super(message);
    }
}
