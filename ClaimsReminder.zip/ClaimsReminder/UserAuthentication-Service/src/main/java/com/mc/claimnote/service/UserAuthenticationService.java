package com.mc.claimnote.service;

import com.mc.claimnote.exception.UserAlreadyExistsException;
import com.mc.claimnote.exception.UserNotFoundException;
import com.mc.claimnote.model.User;

public interface UserAuthenticationService {

    	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    public User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException;

    boolean saveUser(User user) throws UserAlreadyExistsException;
}
